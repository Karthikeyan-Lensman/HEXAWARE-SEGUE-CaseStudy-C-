﻿using CAR_RENTAL_SYSTEM.Main;

namespace CAR_RENTAL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cars m = new Cars();
            m.run();
        }
    }
}
